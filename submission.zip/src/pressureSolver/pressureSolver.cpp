#include "pressureSolver.h"

PressureSolver::PressureSolver(std::shared_ptr<Discretization> discretization) :
    discretization_(discretization)
{
    
}
